# Assistente v2 — "IAssistente", microfone flutuante e comandos

## Como usar
1. Abra o app e toque em **Ativar escuta**. Libere: microfone, contatos e "Exibir sobre outros apps".
2. Uma bolinha 🎤 aparece na tela (arraste para onde quiser; toque nela para falar um comando).
3. Ou diga: **"IAssistente, ..."**

## Comandos
- abre o YouTube / WhatsApp / Instagram / qualquer app instalado
- pesquisa receita de bolo (Google)  |  toca funk no YouTube
- liga para fulano (abre o discador)
- manda mensagem no WhatsApp para fulano dizendo estou chegando (abre a conversa pronta; você toca em enviar)
- me lembra amanhã às 8 de comprar pão  |  me acorda às 6 e meia
- que horas são  |  que dia é hoje
- desligar escuta

## Gerar o APK
GitHub: suba a pasta → Actions → "Build APK" → baixe `assistente-apk`.
Android Studio: Open → Build > Build APK(s).

## Privacidade
O app não tem permissão de internet e não guarda nada fora do aparelho.
O reconhecimento de voz usa o serviço do Google do celular; para ficar offline,
baixe o pacote de voz "Português (Brasil)" em Configurações > Google > Reconhecimento de voz offline.

## Limites
- Após reiniciar o celular, abra o app e ative a escuta de novo (regra do Android 14+).
- Desative a otimização de bateria para o app.
- A chamada "IAssistente" é detectada quando o reconhecedor entende "assistente".
