package com.danilo.assistente

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.startForegroundService(
            Intent(c, AlarmService::class.java)
                .putExtra("id", i.getIntExtra("id", -1))
                .putExtra("text", i.getStringExtra("text"))
        )
    }
}
