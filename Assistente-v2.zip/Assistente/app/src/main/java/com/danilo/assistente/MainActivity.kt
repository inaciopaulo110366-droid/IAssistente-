package com.danilo.assistente

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var toggle: Button
    private var tts: TextToSpeech? = null
    private var items = listOf<Reminder>()
    private var askedPerms = false
    private val br = Locale("pt", "BR")
    private val show = SimpleDateFormat("EEE dd/MM HH:mm", br)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (48 * dp).toInt(), (20 * dp).toInt(), (20 * dp).toInt())
        }
        val title = TextView(this).apply { text = "Assistente"; textSize = 26f; setTypeface(null, Typeface.BOLD) }
        val mic = Button(this).apply { text = "🎤  Toque e fale"; textSize = 20f; setOnClickListener { listen() } }
        toggle = Button(this).apply { textSize = 16f; setOnClickListener { toggleListening() } }
        status = TextView(this).apply {
            text = "Diga \"IAssistente, abre o YouTube\" (com a escuta ativada) ou toque no microfone."
            textSize = 15f
            setPadding(0, (12 * dp).toInt(), 0, (12 * dp).toInt())
        }
        list = ListView(this)
        list.setOnItemClickListener { _, _, pos, _ -> confirmDelete(items[pos]) }
        root.addView(title)
        root.addView(mic, LinearLayout.LayoutParams(-1, (80 * dp).toInt()))
        root.addView(toggle, LinearLayout.LayoutParams(-1, (64 * dp).toInt()))
        root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = br }
    }

    override fun onResume() {
        super.onResume()
        updateToggle()
        refresh()
    }

    private fun updateToggle() {
        toggle.text = if (WakeService.running) "⏹  Desligar escuta" else "👂  Ativar escuta (\"IAssistente\")"
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun toggleListening() {
        if (WakeService.running) {
            stopService(Intent(this, WakeService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ updateToggle() }, 400)
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO) || (!askedPerms && !granted(Manifest.permission.READ_CONTACTS))) {
            askedPerms = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS), 2)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Ative \"Exibir sobre outros apps\" para este app e volte aqui."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, WakeService::class.java))
        status.text = "Escutando. Diga \"IAssistente\" ou toque na bolinha do microfone."
        Handler(Looper.getMainLooper()).postDelayed({ updateToggle() }, 600)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code != 2) return
        if (granted(Manifest.permission.RECORD_AUDIO)) toggleListening()
        else status.text = "Sem a permissão do microfone não dá para ouvir."
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale o comando")
        try { startActivityForResult(i, 10) }
        catch (e: ActivityNotFoundException) { status.text = "Reconhecimento de voz indisponível neste aparelho." }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 10 || res != RESULT_OK) return
        val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        val reply = Commands.run(this, said)
        if (reply == Commands.STOP) {
            stopService(Intent(this, WakeService::class.java)); updateToggle(); return
        }
        status.text = "Ouvi: \"$said\"\n$reply"
        tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "msg")
        refresh()
    }

    private fun confirmDelete(r: Reminder) {
        AlertDialog.Builder(this)
            .setMessage("Apagar \"${r.text}\"?")
            .setPositiveButton("Apagar") { _, _ ->
                Scheduler.cancel(this, r); Store.remove(this, r.id); refresh()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        items = Store.all(this).filter { it.whenMs > now }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            items.map { "${show.format(Date(it.whenMs))} — ${it.text}" })
    }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
