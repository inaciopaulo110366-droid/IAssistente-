package com.danilo.assistente

import java.text.Normalizer
import java.util.Calendar
import java.util.Locale

data class Parsed(val whenMs: Long, val text: String)

/** Entende frases como "me acorda amanhã às 6:30 para tomar remédio" ou "daqui a 20 minutos ligar pro João". */
object Parser {
    private class Txt(var o: String, var s: String) {
        fun blank(r: IntRange) {
            val sp = " ".repeat(r.last - r.first + 1)
            o = o.replaceRange(r, sp); s = s.replaceRange(r, sp)
        }
        fun take(re: Regex): MatchResult? = re.find(s)?.also { blank(it.range) }
        fun takeAll(re: Regex) { while (true) { take(re) ?: break } }
    }

    private val days = listOf("domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado")
    private val trig = Regex("\\b(?:me\\s+)?(?:acorda|acordar|acorde|lembra|lembrar|lembre|avisa|avisar|avise|despertador|alarme|agendar|agenda|agende|marcar|marque|programar|programa|programe|criar|crie|cria|lembrete|compromisso)\\b")
    private val relRe = Regex("(?:daqui a|daqui|em|dentro de)\\s+(?:(\\d+)\\s*(minutos?|min|horas?|h)\\b|(meia hora)|(uma hora)|(um minuto))")
    private val r1 = Regex("\\b(\\d{1,2})\\s*(?::|(?:horas?|hs|h)\\b)\\s*(\\d{2})?(?:\\s+e\\s+(meia|quinze))?")
    private val r2 = Regex("\\b(?:as|pras)\\s+(\\d{1,2})(?:\\s+e\\s+(meia|quinze|\\d{1,2}))?\\b")

    private fun wordMin(x: String) = when (x) { "meia" -> 30; "quinze" -> 15; else -> x.toIntOrNull() ?: 0 }

    fun parse(raw: String): Parsed? {
        val nfc = Normalizer.normalize(raw.trim(), Normalizer.Form.NFC)
        val flat = Normalizer.normalize(nfc, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase(Locale.ROOT)
        val t = if (flat.length == nfc.length) Txt(nfc, flat) else Txt(flat, flat)

        val now = Calendar.getInstance()
        val cal = Calendar.getInstance()

        val rel = t.take(relRe)
        if (rel != null) {
            val g = rel.groupValues
            when {
                g[1].isNotEmpty() -> {
                    val n = g[1].toIntOrNull() ?: return null
                    if (g[2].startsWith("h")) cal.add(Calendar.HOUR_OF_DAY, n) else cal.add(Calendar.MINUTE, n)
                }
                g[3].isNotEmpty() -> cal.add(Calendar.MINUTE, 30)
                g[4].isNotEmpty() -> cal.add(Calendar.HOUR_OF_DAY, 1)
                else -> cal.add(Calendar.MINUTE, 1)
            }
        } else {
            var addDays = -1; var dow = -1; var dom = -1
            if (t.take(Regex("\\bdepois de amanha\\b")) != null) addDays = 2
            else if (t.take(Regex("\\bamanha\\b")) != null) addDays = 1
            else if (t.take(Regex("\\bhoje\\b")) != null) addDays = 0
            t.take(Regex("\\b(domingo|segunda|terca|quarta|quinta|sexta|sabado)(?:-feira)?\\b"))
                ?.let { dow = days.indexOf(it.groupValues[1]) + 1 }

            var hour = -1; var min = 0
            if (t.take(Regex("\\bmeio[ -]dia\\b")) != null) hour = 12
            else if (t.take(Regex("\\bmeia[ -]noite\\b")) != null) hour = 0
            t.take(Regex("\\bdia (\\d{1,2})\\b"))?.let { dom = it.groupValues[1].toInt() }
            if (hour < 0) {
                val m1 = t.take(r1)
                if (m1 != null) {
                    hour = m1.groupValues[1].toInt()
                    min = m1.groupValues[2].toIntOrNull() ?: wordMin(m1.groupValues[3])
                } else {
                    val m2 = t.take(r2)
                    if (m2 != null) { hour = m2.groupValues[1].toInt(); min = wordMin(m2.groupValues[2]) }
                }
            }
            val pm = t.take(Regex("\\b(?:da|de|a)\\s+(tarde|noite)\\b"))
            t.take(Regex("\\b(?:da|de)\\s+(?:manha|madrugada)\\b"))
            if (hour < 0 || hour > 23 || min > 59) return null
            if (pm != null && hour in 1..11) hour += 12

            cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, min)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            when {
                addDays >= 0 -> cal.add(Calendar.DAY_OF_YEAR, addDays)
                dow > 0 -> {
                    cal.add(Calendar.DAY_OF_YEAR, (dow - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7)
                    if (cal.timeInMillis <= now.timeInMillis) cal.add(Calendar.DAY_OF_YEAR, 7)
                }
                dom > 0 -> {
                    cal.set(Calendar.DAY_OF_MONTH, dom.coerceIn(1, 31))
                    if (cal.timeInMillis <= now.timeInMillis) cal.add(Calendar.MONTH, 1)
                }
                else -> if (cal.timeInMillis <= now.timeInMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        if (cal.timeInMillis <= now.timeInMillis) return null

        t.takeAll(trig)
        val edge = "(?:as|às|a|para|pra|pras|de|que|e|em|um|uma|do|da|no|na|pro|dia)"
        val text = t.o.replace(Regex("\\s+"), " ").trim()
            .replace(Regex("^(?:$edge\\s+)+", RegexOption.IGNORE_CASE), "")
            .replace(Regex("(?:\\s+$edge)+$", RegexOption.IGNORE_CASE), "")
            .trim(' ', ',', '.')
        return Parsed(cal.timeInMillis, text.ifBlank { "Despertador" })
    }
}
