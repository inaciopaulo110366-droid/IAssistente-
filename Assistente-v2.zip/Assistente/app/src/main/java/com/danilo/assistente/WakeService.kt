package com.danilo.assistente

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs

/**
 * Escuta sempre (serviço em primeiro plano, com notificação fixa) e mostra um microfone flutuante.
 * Chame dizendo "IAssistente ..." ou toque na bolinha do microfone.
 */
class WakeService : Service(), TextToSpeech.OnInitListener {
    companion object { @Volatile var running = false }

    private val h = Handler(Looper.getMainLooper())
    private val wake = Regex("assistente")
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var onSpoken: (() -> Unit)? = null
    private var busy = false
    private var commandMode = false
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private lateinit var am: AudioManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        am = getSystemService(AudioManager::class.java)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("escuta", "Escuta do assistente", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 3, Intent(this, WakeService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "escuta")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Assistente ouvindo")
            .setContentText("Diga \"IAssistente\" para chamar")
            .setOngoing(true)
            .addAction(0, "Desligar", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(2, n)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
        tts = TextToSpeech(this, this)
        showBubble()
        startListening()
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") stopSelf()
        return START_STICKY
    }

    // ---------- Voz (TTS) ----------
    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts?.language = Locale("pt", "BR")
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.post { done() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { h.post { done() } }
        })
        ttsReady = true
    }

    private fun done() { val cb = onSpoken; onSpoken = null; cb?.invoke() }

    private fun speak(text: String, then: () -> Unit) {
        rec?.cancel()
        if (!ttsReady) { then(); return }
        onSpoken = then
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "r")
    }

    // ---------- Escuta ----------
    private val again = Runnable { startListening() }
    private fun restart(ms: Long) { h.removeCallbacks(again); h.postDelayed(again, ms) }

    private fun resetRec() { try { rec?.destroy() } catch (_: Exception) {}; rec = null }

    private fun beepMute(on: Boolean) {
        try {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
        } catch (_: Exception) {}
    }

    private fun startListening() {
        if (!running || busy) return
        try {
            if (rec == null) rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            beepMute(true)           // silencia o "bip" do reconhecedor
            rec?.startListening(i)
            h.postDelayed({ beepMute(false) }, 700)
        } catch (e: Exception) {
            resetRec(); restart(1500)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, b: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onResults(b: Bundle?) { onFinal(b) }
        override fun onError(e: Int) { onRecError(e) }
    }

    private fun onRecError(e: Int) {
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
        if (busy) return
        if (commandMode) { commandMode = false; setBubble(false) }
        when (e) {
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> { resetRec(); restart(1200) }
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(250)
            else -> restart(1500)
        }
    }

    private fun cutAfterWake(text: String): String? {
        val f = Commands.flat(text)
        val m = wake.find(f) ?: return null
        return (if (f.length == text.length) text else f).substring(m.range.last + 1).trim(' ', ',', '.', ':', '!')
    }

    private fun onFinal(b: Bundle?) {
        if (busy) return
        val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        if (commandMode) {
            commandMode = false
            if (text.isBlank()) { setBubble(false); restart(250) } else execute(cutAfterWake(text) ?: text)
            return
        }
        val cmd = cutAfterWake(text)
        when {
            cmd == null -> restart(150)
            cmd.length >= 3 -> execute(cmd)
            else -> prompt()
        }
    }

    private fun prompt() {
        busy = true; setBubble(true)
        speak("Pois não?") { busy = false; commandMode = true; startListening() }
    }

    private fun execute(cmd: String) {
        busy = true; setBubble(true)
        val reply = try { Commands.run(this, cmd) } catch (e: Exception) { "Não consegui fazer isso." }
        if (reply == Commands.STOP) { speak("Desligando a escuta.") { stopSelf() }; return }
        speak(reply) { busy = false; setBubble(false); startListening() }
    }

    // ---------- Microfone flutuante ----------
    private fun circle(color: String) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(Color.parseColor(color))
    }

    private fun setBubble(listening: Boolean) {
        bubble?.background = circle(if (listening) "#E6D32F2F" else "#E61565C0")
    }

    private fun onBubbleTap() {
        if (busy) return
        rec?.cancel()
        commandMode = true
        setBubble(true)
        h.postDelayed({ startListening() }, 200)
    }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this)) return
        val w = getSystemService(WindowManager::class.java)
        wm = w
        val dp = resources.displayMetrics.density
        val size = (60 * dp).toInt()
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * dp).toInt(); y = (240 * dp).toInt() }
        val tv = TextView(this).apply {
            text = "🎤"; textSize = 24f; gravity = Gravity.CENTER; background = circle("#E61565C0")
        }
        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = sx + dx; lp.y = sy + dy
                        w.updateViewLayout(v, lp)
                    }
                    MotionEvent.ACTION_UP -> if (!moved) onBubbleTap()
                }
                return true
            }
        })
        w.addView(tv, lp)
        bubble = tv
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        beepMute(false)
        resetRec()
        tts?.shutdown()
        bubble?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
