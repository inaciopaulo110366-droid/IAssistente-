package com.danilo.assistente

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Toca o alarme e FALA o lembrete em voz alta, repetindo algumas vezes. */
class AlarmService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ringtone: Ringtone? = null
    private val h = Handler(Looper.getMainLooper())
    private var text = "Despertador"
    private var rounds = 0
    private var stopped = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        cleanup()
        stopped = false; rounds = 0
        text = i?.getStringExtra("text") ?: text
        Store.remove(this, i?.getIntExtra("id", -1) ?: -1)
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
        ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))?.apply {
            audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        }
        tts = TextToSpeech(this, this)
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            // Sem voz disponível: só toca o alarme por 1 minuto.
            if (Build.VERSION.SDK_INT >= 28) ringtone?.isLooping = true
            ringtone?.play()
            h.postDelayed({ stopSelf() }, 60000)
            return
        }
        tts?.language = Locale("pt", "BR")
        tts?.setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        )
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.postDelayed({ cycle() }, 1500) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { h.postDelayed({ cycle() }, 1500) }
        })
        cycle()
    }

    private fun cycle() {
        if (stopped || rounds++ >= 6) { stopSelf(); return }
        ringtone?.play()
        h.postDelayed({
            ringtone?.stop()
            tts?.speak("Está na hora! $text", TextToSpeech.QUEUE_FLUSH, null, "lembrete")
        }, 3500)
    }

    private fun createChannel() {
        val ch = NotificationChannel("alarme", "Alarmes", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, AlarmActivity::class.java).putExtra("text", text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, AlarmService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "alarme")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Lembrete")
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .addAction(0, "Parar", stop)
            .setOngoing(true)
            .build()
    }

    private fun cleanup() {
        h.removeCallbacksAndMessages(null)
        ringtone?.stop()
        tts?.stop(); tts?.shutdown(); tts = null
    }

    override fun onDestroy() {
        stopped = true
        cleanup()
        super.onDestroy()
    }
}
