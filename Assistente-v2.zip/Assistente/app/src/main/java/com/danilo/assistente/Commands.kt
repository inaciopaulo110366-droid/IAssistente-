package com.danilo.assistente

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Interpreta o que você falou e executa. Devolve a frase que o assistente vai falar. */
object Commands {
    const val STOP = "__STOP__"
    private val br = Locale("pt", "BR")
    private val speakFmt = SimpleDateFormat("EEEE, d 'de' MMMM 'às' H 'horas e' mm 'minutos'", br)

    fun flat(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase(Locale.ROOT)

    // Pega o trecho do texto original (com acentos) correspondente ao intervalo achado no texto "plano".
    private fun slice(said: String, f: String, r: IntRange): String =
        (if (said.length == f.length) said else f).substring(r.first, r.last + 1).trim(' ', ',', '.', '!', '?')

    private val alias = mapOf(
        "zap" to "whatsapp", "zap zap" to "whatsapp", "zapzap" to "whatsapp", "whats" to "whatsapp",
        "insta" to "instagram", "tik tok" to "tiktok", "you tube" to "youtube", "face" to "facebook",
        "ajustes" to "configuracoes", "configuracao" to "configuracoes"
    )

    fun run(c: Context, said: String): String {
        val f = flat(said)

        if (Regex("\\b(?:parar de ouvir|desligar (?:a )?(?:escuta|assistente)|desativar (?:a )?escuta)\\b").containsMatchIn(f)) return STOP

        // 1) Lembrete / despertador
        val hasTrig = Regex("\\b(?:acorda|acordar|acorde|lembra|lembrar|lembre|alarme|despertador|agenda|agendar|agende|marca|marcar|marque|avisa|avisar|avise|programa|programar|programe|lembrete)\\b").containsMatchIn(f)
        if (hasTrig) {
            val p = Parser.parse(said)
            if (p != null) {
                val r = Reminder((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), p.whenMs, p.text)
                Store.add(c, r); Scheduler.set(c, r)
                return "Combinado! Vou te avisar: ${p.text}, ${speakFmt.format(Date(p.whenMs))}."
            }
        }

        // 2) Hora e data
        if (Regex("\\bque horas\\b").containsMatchIn(f))
            return "Agora são " + SimpleDateFormat("H 'horas e' mm 'minutos'", br).format(Date())
        if (Regex("\\bque dia\\b").containsMatchIn(f))
            return "Hoje é " + SimpleDateFormat("EEEE, d 'de' MMMM", br).format(Date())

        // 3) Mensagem de WhatsApp (abre a conversa com o texto pronto; você toca em enviar)
        Regex("\\b(?:manda|mandar|envia|enviar|escreve|escrever)\\s+(?:uma\\s+)?(?:mensagem|msg|zap|whatsapp)\\s+(?:no\\s+whatsapp\\s+|pelo\\s+whatsapp\\s+|no\\s+zap\\s+)?(?:para|pra)\\s+(.+?)\\s+(?:dizendo|falando|escrevendo|que)\\s+(.+)")
            .find(f)?.let { m ->
                val name = slice(said, f, m.groups[1]!!.range)
                val msg = slice(said, f, m.groups[2]!!.range)
                val num = findNumber(c, name) ?: return "Não encontrei $name nos contatos."
                var d = num.filter { it.isDigit() }
                if (d.length in 10..11) d = "55$d"
                view(c, "https://wa.me/$d?text=" + Uri.encode(msg), "com.whatsapp")
                return "Abri o WhatsApp com a mensagem para $name. É só tocar em enviar."
            }

        // 4) Ligar
        Regex("\\b(?:liga|ligar|chama|chamar|telefona|telefonar)\\s+(?:para|pra|o|a)?\\s*(.+)").find(f)?.let { m ->
            val name = slice(said, f, m.groups[1]!!.range)
            val num = findNumber(c, name) ?: return "Não encontrei $name nos contatos."
            c.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Abrindo o discador para $name."
        }

        // 5) YouTube
        val yt = Regex("\\b(?:toca|tocar|toque|busca|buscar|procura|procurar|pesquisa|pesquisar|ver|assistir)\\s+(.+?)\\s+(?:no|na|do)\\s+youtube\\b").find(f)
            ?: Regex("\\byoutube\\s+(?:e\\s+)?(?:pesquisa|busca|procura|toca)\\s+(.+)").find(f)
        if (yt != null) {
            val q = slice(said, f, yt.groups[1]!!.range)
            view(c, "https://www.youtube.com/results?search_query=" + Uri.encode(q), "com.google.android.youtube")
            return "Procurando $q no YouTube."
        }

        // 6) Abrir aplicativo (qualquer app instalado)
        Regex("\\b(?:abre|abrir|abra|inicia|iniciar|entra no|entrar no|vai para o|ir para o)\\s+(?:o\\s+|a\\s+|os\\s+|as\\s+)?(?:aplicativo\\s+|app\\s+)?(.+)")
            .find(f)?.let { m -> return openApp(c, m.groups[1]!!.value.trim()) }

        // 7) Pesquisa no Google
        Regex("\\b(?:pesquisa|pesquisar|procura|procurar|busca|buscar|googla)\\s+(?:no\\s+google\\s+)?(?:por\\s+|sobre\\s+)?(.+)").find(f)?.let { m ->
            val q = slice(said, f, m.groups[1]!!.range).replace(Regex("\\s+no google$", RegexOption.IGNORE_CASE), "")
            if (q.isNotBlank()) {
                view(c, "https://www.google.com/search?q=" + Uri.encode(q), null)
                return "Pesquisando $q no Google."
            }
        }

        if (hasTrig) return "Não entendi o horário. Diga, por exemplo: me lembra amanhã às 8 de comprar pão."
        return "Não entendi. Você pode dizer: abre o YouTube, pesquisa receita de bolo, liga para fulano, ou me lembra amanhã às 8 de comprar pão."
    }

    private fun view(c: Context, url: String, pkg: String?) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) {
            try { c.startActivity(Intent(i).setPackage(pkg)); return } catch (_: Exception) {}
        }
        c.startActivity(i)
    }

    private fun openApp(c: Context, spoken: String): String {
        val want = alias[spoken] ?: spoken
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { flat(it.loadLabel(pm).toString()) to it }
        val hit = apps.firstOrNull { it.first == want }
            ?: apps.firstOrNull { it.first.contains(want) }
            ?: apps.firstOrNull { it.first.length >= 4 && want.contains(it.first) }
            ?: return "Não achei o aplicativo $spoken."
        val i = pm.getLaunchIntentForPackage(hit.second.activityInfo.packageName) ?: return "Não consegui abrir $spoken."
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Abrindo ${hit.second.loadLabel(pm)}."
    }

    private fun findNumber(c: Context, name: String): String? {
        val digits = name.filter { it.isDigit() }
        if (digits.length >= 8) return digits
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val target = flat(name).trim()
        if (target.isEmpty()) return null
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { cur ->
            var best: String? = null
            while (cur.moveToNext()) {
                val n = flat(cur.getString(0) ?: "")
                if (n == target) return cur.getString(1)
                if (best == null && n.contains(target)) best = cur.getString(1)
            }
            return best
        }
        return null
    }
}
