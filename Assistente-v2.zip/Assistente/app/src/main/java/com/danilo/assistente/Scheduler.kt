package com.danilo.assistente

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Scheduler {
    private fun pi(c: Context, r: Reminder) = PendingIntent.getBroadcast(
        c, r.id,
        Intent(c, AlarmReceiver::class.java).putExtra("id", r.id).putExtra("text", r.text),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun set(c: Context, r: Reminder) {
        val am = c.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        // setAlarmClock: preciso, acorda o aparelho e não exige permissão de alarme exato.
        am.setAlarmClock(AlarmManager.AlarmClockInfo(r.whenMs, show), pi(c, r))
    }

    fun cancel(c: Context, r: Reminder) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, r))
    }
}
