package com.danilo.assistente

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Reminder(val id: Int, val whenMs: Long, val text: String)

/** Sem banco de dados: lista simples em SharedPreferences (JSON). */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("lembretes", Context.MODE_PRIVATE)

    fun all(c: Context): List<Reminder> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Reminder(o.getInt("id"), o.getLong("t"), o.getString("x"))
        }.sortedBy { it.whenMs }
    }

    private fun save(c: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("t", it.whenMs).put("x", it.text)) }
        sp(c).edit().putString("list", arr.toString()).apply()
    }

    fun add(c: Context, r: Reminder) = save(c, all(c) + r)
    fun remove(c: Context, id: Int) = save(c, all(c).filter { it.id != id })
}
