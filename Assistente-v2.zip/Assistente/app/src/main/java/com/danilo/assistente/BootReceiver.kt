package com.danilo.assistente

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val now = System.currentTimeMillis()
        Store.all(c).filter { it.whenMs > now }.forEach { Scheduler.set(c, it) }
    }
}
