package com.danilo.assistente

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

@Suppress("DEPRECATION")
class AlarmActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding((24 * dp).toInt(), 0, (24 * dp).toInt(), 0)
        }
        val msg = TextView(this).apply {
            text = intent.getStringExtra("text") ?: "Despertador"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val stop = Button(this).apply {
            text = "PARAR"
            textSize = 24f
            setOnClickListener {
                startService(Intent(this@AlarmActivity, AlarmService::class.java).setAction("STOP"))
                finish()
            }
        }
        root.addView(msg)
        root.addView(stop, LinearLayout.LayoutParams(-1, (110 * dp).toInt()).apply { topMargin = (40 * dp).toInt() })
        setContentView(root)
    }
}
